# HalfBaked SDK

![Status](https://img.shields.io/badge/Status-Beta-blue)
![Stability](https://img.shields.io/badge/Stability-Pre--Release-yellow)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A robust TypeScript SDK for seamless cross-chain token launching, trading, and liquidity management across Solana, Base, NEAR, and Ethereum. Built on top of Meteora SDK, NEAR Intents, Omnibridge, and leading DEXes.

> [!IMPORTANT]
> This SDK is in beta and approaching production readiness. While core functionality is stable, some features may still change. We recommend thorough testing before using in production environments.


## 🚀 Quick Start

```bash
npm install @cookedbusiness/halfbaked-sdk
# or
pnpm add @cookedbusiness/halfbaked-sdk
# or
yarn add @cookedbusiness/halfbaked-sdk
```

## 📚 Core Features

### Token Launch & Trading
- **Dynamic Bonding Curves (DBC)**: Launch tokens with automated price discovery
- **Token Trading**: Buy/sell tokens directly from bonding curves
- **Cross-chain Bridging**: Seamless token transfers across supported chains
- **NEAR Intents**: Cross-chain swapping with native asset support

### Liquidity Management
- **Multi-DEX Support**: Raydium, Orca, Jupiter (Solana), Aerodrome (Base), Ref Finance (NEAR)
- **Automated Liquidity**: Add/remove liquidity with optimal routing
- **Pool Management**: Create pools, manage positions, and track performance

### Supported Chains & DEXes
- **Solana**: Raydium, Orca, Jupiter (aggregator), PumpSwap (pump.fun)
- **Base**: Aerodrome ✅ **PRODUCTION READY**
- **NEAR**: Ref Finance, Jumbo Exchange

## 🛠️ Examples

### Token Creation
Create and deploy tokens with bonding curves:

```bash
npm run example:create-token
```

**Features:**
- Complete token deployment workflow
- Automatic metadata upload to IPFS
- Bonding curve pricing mechanism
- Database integration with PotLaunch
- Comprehensive error handling

### Token Trading
Buy and sell tokens directly from bonding curves:

```bash
npm run example:trading-token
```

**Features:**
- Direct bonding curve interaction
- Buy/sell operations with SOL
- Fee recipient support
- Transaction confirmation and tracking

### NEAR Intents Cross-Chain Swapping
Execute cross-chain swaps using NEAR Intents:

```bash
npm run example:near-intents
```

**Features:**
- Cross-chain token swaps
- Native asset support (NEAR, SOL, USDC, USDT, wETH)
- Quote generation and execution
- Settlement tracking

### Aerodrome DEX Integration ✅ **NEW**
Complete Aerodrome DEX operations on Base:

```bash
npm run example:aerodrome
```

**Features:**
- Pool creation (volatile and stable pools)
- Liquidity addition/removal with auto-approval
- Pool discovery and filtering
- Position tracking and management
- PotLaunch treasury fee routing (10% automatic)
- Production-grade security and validation
- Comprehensive error handling
- 70+ tests covering all scenarios

### Jupiter Aggregator
Token swapping using Jupiter aggregator on Solana:

```bash
npm run example:jupiter
```

**Features:**
- Optimal route finding
- Quote generation
- Price discovery
- Advanced swap options
- Error handling

### PumpSwap (pump.fun)
Buy and sell tokens on pump.fun bonding curves:

See `examples/pumpswap-example.ts` for complete usage examples.

**Features:**
- Buy tokens on bonding curve
- Sell tokens on bonding curve
- Get swap quotes
- Pool state information
- Transaction simulation (dry run)
- Slippage protection
- Priority fee support

### Migration Examples
Migrate between different token mechanisms:

```bash
npm run example:migrate-dbc-to-damm
```

### Pool State Checking
Monitor and check pool states:

```bash
npm run example:check-pool-state
```

## 🧪 Testing

### Run All Tests
```bash
npm test
```

### Run Specific Test Suites
```bash
# Launch functionality tests
npm run test:launch

# NEAR Intents tests
npm run test:near-intents

# Bridge functionality tests
npm run test:bridge
```

### Test Configuration
The SDK uses Vitest for testing with comprehensive coverage:
- Parameter validation tests
- Error handling tests
- Type safety tests
- Integration tests for all supported chains

## 📖 Documentation

Detailed documentation is available in the `docs/` folder:

- [Token Creation Guide](./docs/create-token-example.md)
- [Trading Token Guide](./docs/trading-token-example.md)
- [NEAR Intents Guide](./docs/near-intents.md)
- [Aerodrome Integration](./docs/aerodrome-integration.md)
- [Jupiter Integration](./docs/jupiter-integration.md)
- [PumpSwap Integration](./docs/pumpswap-integration.md)
- [Raydium Integration](./docs/raydium-integration.md)
- [Orca Integration](./docs/orca-integration-guide.md)

## 🔧 Configuration

### Environment Setup
Create a `.env` file with your configuration:

```env
# Required for token operations
PRIVATE_KEY=your_base58_private_key

# Required for NEAR Intents
ONECLICK_JWT=your_jwt_token

# Optional: NEAR account for programmatic transfers
SENDER_NEAR_ACCOUNT=your_near_account
SENDER_PRIVATE_KEY=your_near_private_key
```

### SDK Configuration
```typescript
import { DEFAULT_SDK_CONFIG } from '@cookedbusiness/halfbaked-sdk';

const config = {
  ...DEFAULT_SDK_CONFIG,
  defaultSlippage: 1.0, // 1% default slippage
  maxRetries: 5,
  timeoutMs: 60000 // 60 seconds
};
```

## 🔗 Integration Examples

### Basic Token Launch
```typescript
import { LaunchClient } from '@cookedbusiness/halfbaked-sdk';
import { Connection, Keypair } from '@solana/web3.js';

const connection = new Connection('https://api.devnet.solana.com');
const wallet = Keypair.generate();
const launchClient = new LaunchClient(connection, wallet);

// Deploy token with bonding curve
const result = await launchClient.deployToken(dbcConfig, quoteMint);
```

### Cross-Chain Swap with NEAR Intents
```typescript
import { NearIntents } from '@cookedbusiness/halfbaked-sdk';

const intents = new NearIntents(jwtToken, apiBaseUrl);

const result = await intents.nearIntentSwap({
  inputToken: 'wNEAR',
  outputToken: 'SOL',
  amount: '100000000000000000000000', // 0.1 NEAR
  slippage: 0.5,
  senderAddress: 'your.near',
  senderPrivateKey: 'your_private_key',
  recipientAddress: 'solana_address',
  waitForSettlement: true
});
```

### PumpSwap Trading
```typescript
import { PumpSwapManager } from '@cookedbusiness/halfbaked-sdk';
import { Connection, Keypair, PublicKey } from '@solana/web3.js';
import BN from 'bn.js';

const connection = new Connection('https://api.mainnet-beta.solana.com');
const wallet = Keypair.fromSecretKey(/* your key */);
const pumpSwap = new PumpSwapManager(connection, wallet);

// Buy tokens on bonding curve
const buyResult = await pumpSwap.buy({
  pool: new PublicKey('POOL_ADDRESS'),
  baseMint: new PublicKey('TOKEN_MINT'),
  quoteMint: new PublicKey('So11111111111111111111111111111111111111112'), // SOL
  amount: new BN(1_000_000_000), // 1 token
  slippageBps: 50 // 0.5% slippage
});

// Sell tokens on bonding curve
const sellResult = await pumpSwap.sell({
  pool: new PublicKey('POOL_ADDRESS'),
  baseMint: new PublicKey('TOKEN_MINT'),
  quoteMint: new PublicKey('So11111111111111111111111111111111111111112'),
  amount: new BN(1_000_000_000),
  slippageBps: 50
});
```

### Liquidity Management
```typescript
import { AerodromeLiquidityManager } from '@cookedbusiness/halfbaked-sdk';

const manager = new AerodromeLiquidityManager(config);

// Add liquidity
const result = await manager.addLiquidity({
  chain: 'base',
  dex: 'aerodrome',
  tokenA: 'USDC_ADDRESS',
  tokenB: 'WETH_ADDRESS',
  amountA: '1000',
  amountB: '0.5',
  wallet: walletInfo,
  slippage: 0.5
});
```

## 🛡️ Security

- **Hard-coded Treasury Addresses**: Secure fee collection
- **Private Key Management**: Environment variable support
- **Anti-rug Mechanisms**: Allocation tracking and vesting
- **Comprehensive Error Handling**: Detailed error messages with actionable steps

## 🔄 Supported Operations

### Token Operations
- Token creation and deployment
- Bonding curve management
- Cross-chain bridging
- Metadata management

### Trading Operations
- Direct bonding curve trading
- Cross-chain swaps
- Price discovery
- Quote generation

### Liquidity Operations
- Pool creation
- Liquidity addition/removal
- Position management
- Fee estimation

## 📊 Error Handling

The SDK provides comprehensive error handling:

```typescript
try {
  await manager.addLiquidity(params);
} catch (error) {
  if (error.code === 'INSUFFICIENT_FUNDS') {
    console.log('Add more funds to your wallet');
  } else if (error.code === 'SLIPPAGE_EXCEEDED') {
    console.log('Increase slippage tolerance');
  }

  console.log('Error:', error.message);
  console.log('Suggested Action:', error.suggestedAction);
}
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests for new functionality
5. Submit a pull request

## 📄 License

MIT License - see [LICENSE](LICENSE) file for details.

## 🆘 Support

- **Documentation**: Check the `docs/` folder for detailed guides
- **Examples**: Run the example scripts to understand usage
- **Issues**: Report bugs and feature requests on GitHub
- **Community**: Join our community for support and discussions

## 🔗 Links

- **Repository**: [GitHub](https://github.com/cookedlabs/halfbaked-sdk)
- **NPM Package**: [@cookedbusiness/halfbaked-sdk](https://www.npmjs.com/package/@cookedbusiness/halfbaked-sdk)
- **Documentation**: [docs/](./docs/)
- **Examples**: [examples/](./examples/)
